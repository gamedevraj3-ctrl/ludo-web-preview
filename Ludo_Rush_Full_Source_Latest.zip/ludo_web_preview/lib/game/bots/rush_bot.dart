import '../board_map.dart';
import 'bot_context.dart';

/// Rush: protect high-value tokens, bank HOME, steal points.
class RushBot implements BotBrain {
  const RushBot();

  @override
  int choose(BotContext ctx) {
    if (ctx.options.length == 1) return ctx.options.first;
    if (ctx.botLevel == 1) {
      return ctx.options[(ctx.rng() * ctx.options.length).floor() %
          ctx.options.length];
    }

    final p = ctx.player;
    final d = ctx.dice;
    var bestScore = -1e9;
    var best = ctx.options.first;

    final dangerNow = <int, double>{};
    for (final t in p.tokens) {
      dangerNow[t.index] = t.onBoard ? ctx.threatAt(p, t.pos) : 0;
    }

    for (final idx in ctx.options) {
      final t = p.tokens[idx];
      var s = 0.0;

      if (!t.open) {
        s += 140;
        s += (4 - p.tokens.where((x) => x.onBoard).length) * 50;
        if (s > bestScore) {
          bestScore = s;
          best = idx;
        }
        continue;
      }

      final np = t.pos + d;
      final victims = ctx.cutVictims(p, np);
      final formsBlock =
          np <= BoardMap.lastRingStep && ctx.myTokensAt(p, np, exclude: idx) >= 1;
      final landsSafe = np > BoardMap.lastRingStep ||
          BoardMap.isSafePos(p.color, np) ||
          formsBlock;
      final threat = landsSafe ? 0.0 : ctx.threatAt(p, np);
      final wasDanger = dangerNow[idx] ?? 0.0;
      final carried = t.carried.toDouble();

      for (final v in victims) {
        s += 380 + v.value * 5.5;
      }
      if (np == BoardMap.homeStep) {
        s += 950 + carried * 2;
      } else if (np > BoardMap.lastRingStep) {
        s += 300 + (np - BoardMap.lastRingStep) * 16;
        s += carried * 1.2;
      }
      if (!landsSafe) {
        s -= threat * (80 + carried * 3.5 + t.pos * 1.5);
      } else {
        s += 150;
        if (formsBlock) s += 120;
      }
      if (wasDanger > 0.12) {
        final nowD = landsSafe ? 0.0 : threat;
        if (nowD < wasDanger) {
          s += (wasDanger - nowD) * (110 + carried * 4 + t.pos);
        }
      }
      s += t.pos * 0.5 + carried * 0.35;
      if (ctx.remainingMatchSeconds < 90 && np > BoardMap.lastRingStep) s += 180;
      if (ctx.remainingMatchSeconds < 45 && np == BoardMap.homeStep) s += 220;
      if (ctx.myTokensAt(p, np, exclude: idx) >= 3) s -= 40;
      s += ctx.rng() * (ctx.hard ? 18 : 55);
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }
}
