import '../board_map.dart';
import 'bot_context.dart';

/// Classic: blocks, defence, strategic cuts, home race.
class ClassicBot implements BotBrain {
  const ClassicBot();

  @override
  int choose(BotContext ctx) {
    if (ctx.options.length == 1) return ctx.options.first;
    if (ctx.botLevel == 1) {
      return ctx.options[(ctx.rng() * ctx.options.length).floor() %
          ctx.options.length];
    }

    final p = ctx.player;
    final d = ctx.dice;
    var bestScore = -1e9;
    var best = ctx.options.first;

    final dangerNow = <int, double>{};
    for (final t in p.tokens) {
      dangerNow[t.index] = t.onBoard ? ctx.threatAt(p, t.pos) : 0;
    }

    for (final idx in ctx.options) {
      final t = p.tokens[idx];
      var s = 0.0;

      if (!t.open) {
        s += 140;
        s += (4 - p.tokens.where((x) => x.onBoard).length) * 50;
        if (ctx.wouldCutAtStart(p)) s += 280;
        if (p.tokens.where((x) => x.onBoard).isEmpty) s += 80;
        if (s > bestScore) {
          bestScore = s;
          best = idx;
        }
        continue;
      }

      final np = t.pos + d;
      final victims = ctx.cutVictims(p, np);
      final formsBlock =
          np <= BoardMap.lastRingStep && ctx.myTokensAt(p, np, exclude: idx) >= 1;
      final landsSafe = np > BoardMap.lastRingStep ||
          BoardMap.isSafePos(p.color, np) ||
          formsBlock;
      final threat = landsSafe ? 0.0 : ctx.threatAt(p, np);
      final wasDanger = dangerNow[idx] ?? 0.0;

      for (final v in victims) {
        s += 340 + v.value * 3.2;
        if (v.value > 40) s += 80;
      }
      if (np == BoardMap.homeStep) {
        s += 1300;
      } else if (np > BoardMap.lastRingStep) {
        s += 300 + (np - BoardMap.lastRingStep) * 20;
      }
      if (formsBlock) s += 260;
      if (landsSafe) {
        s += 150;
      } else {
        s -= threat * (75 + t.pos * 1.8);
      }
      if (wasDanger > 0.15) {
        final nowD = landsSafe ? 0.0 : threat;
        if (nowD < wasDanger) s += (wasDanger - nowD) * (120 + t.pos * 1.5);
      }
      s += t.pos * 0.9;
      if (t.pos > 44) s += 40;
      if (p.tokensYarded > 0 && d == 6 && t.pos < 10) s -= 25;
      if (ctx.myTokensAt(p, np, exclude: idx) >= 3) s -= 50;
      s += ctx.rng() * (ctx.hard ? 14 : 45);
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }
}
