import '../board_map.dart';
import 'bot_context.dart';

/// Kill mode: first cut unlocks HOME, then race + defence.
class KillBot implements BotBrain {
  const KillBot();

  @override
  int choose(BotContext ctx) {
    if (ctx.options.length == 1) return ctx.options.first;
    if (ctx.botLevel == 1) {
      return ctx.options[(ctx.rng() * ctx.options.length).floor() %
          ctx.options.length];
    }

    final p = ctx.player;
    final d = ctx.dice;
    var bestScore = -1e9;
    var best = ctx.options.first;

    final dangerNow = <int, double>{};
    for (final t in p.tokens) {
      dangerNow[t.index] = t.onBoard ? ctx.threatAt(p, t.pos) : 0;
    }

    for (final idx in ctx.options) {
      final t = p.tokens[idx];
      var s = 0.0;

      if (!t.open) {
        s += 140;
        s += (4 - p.tokens.where((x) => x.onBoard).length) * 50;
        if (ctx.wouldCutAtStart(p)) s += 900;
        if (p.tokens.where((x) => x.onBoard).isEmpty) s += 80;
        if (s > bestScore) {
          bestScore = s;
          best = idx;
        }
        continue;
      }

      final np = t.pos + d;
      final victims = ctx.cutVictims(p, np);
      final formsBlock =
          np <= BoardMap.lastRingStep && ctx.myTokensAt(p, np, exclude: idx) >= 1;
      final landsSafe = np > BoardMap.lastRingStep ||
          BoardMap.isSafePos(p.color, np) ||
          formsBlock;
      final threat = landsSafe ? 0.0 : ctx.threatAt(p, np);
      final wasDanger = dangerNow[idx] ?? 0.0;

      for (final v in victims) {
        s += p.homeUnlocked ? 520 : 1600;
        s += v.value * 2.0;
      }
      if (p.homeUnlocked) {
        if (np == BoardMap.homeStep) {
          s += 1250;
        } else if (np > BoardMap.lastRingStep) {
          s += 280 + (np - BoardMap.lastRingStep) * 18;
        }
        s += t.pos * 0.95;
      } else {
        if (np > BoardMap.lastRingStep) s -= 200;
        s += t.pos * 0.35;
      }
      if (formsBlock) s += 220;
      if (landsSafe) s += 140;
      if (!landsSafe) s -= threat * (70 + t.pos * 1.6);
      if (wasDanger > 0.15) {
        final nowD = landsSafe ? 0.0 : threat;
        if (nowD < wasDanger) s += (wasDanger - nowD) * (100 + t.pos);
      }
      s += ctx.rng() * (ctx.hard ? 16 : 50);
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }
}
