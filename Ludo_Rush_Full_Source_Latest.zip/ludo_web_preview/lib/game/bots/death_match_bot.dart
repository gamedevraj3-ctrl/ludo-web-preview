import '../board_map.dart';
import 'bot_context.dart';

/// Death Match: hunt kills, stack defence, ignore HOME.
class DeathMatchBot implements BotBrain {
  const DeathMatchBot();

  @override
  int choose(BotContext ctx) {
    if (ctx.options.length == 1) return ctx.options.first;
    if (ctx.botLevel == 1) {
      return ctx.options[(ctx.rng() * ctx.options.length).floor() %
          ctx.options.length];
    }

    final p = ctx.player;
    final d = ctx.dice;
    final killsNeeded = (ctx.killTarget - p.cutsMade).clamp(0, 99);
    var bestScore = -1e9;
    var best = ctx.options.first;

    final dangerNow = <int, double>{};
    for (final t in p.tokens) {
      dangerNow[t.index] = t.onBoard ? ctx.threatAt(p, t.pos) : 0;
    }

    for (final idx in ctx.options) {
      final t = p.tokens[idx];
      var s = 0.0;

      if (!t.open) {
        s += 140;
        s += (4 - p.tokens.where((x) => x.onBoard).length) * 50;
        if (ctx.wouldCutAtStart(p)) s += 280;
        if (s > bestScore) {
          bestScore = s;
          best = idx;
        }
        continue;
      }

      final np = t.pos + d;
      final victims = ctx.cutVictims(p, np);
      final formsBlock =
          np <= BoardMap.lastRingStep && ctx.myTokensAt(p, np, exclude: idx) >= 1;
      final landsSafe = np > BoardMap.lastRingStep ||
          BoardMap.isSafePos(p.color, np) ||
          formsBlock;
      final threat = landsSafe ? 0.0 : ctx.threatAt(p, np);
      final wasDanger = dangerNow[idx] ?? 0.0;

      for (final v in victims) {
        s += 2400;
        s += v.player.cutsMade * 40.0;
      }
      if (formsBlock) s += 320;
      if (landsSafe) s += 160;
      if (!landsSafe && victims.isEmpty) {
        s -= threat * (140 + t.pos * 2.2);
      }
      if (wasDanger > 0.2) {
        final nowD = landsSafe ? 0.0 : threat;
        if (nowD < wasDanger) s += (wasDanger - nowD) * 160;
      }
      if (np == BoardMap.homeStep) {
        s += 15;
      } else if (np > BoardMap.lastRingStep) {
        s += 5;
      }
      if (t.pos >= 12 && t.pos <= 45 && victims.isEmpty) s += 12;
      if (killsNeeded <= 2) s += victims.isNotEmpty ? 200 : 0;
      s += ctx.rng() * (ctx.hard ? 12 : 40);
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }
}
