import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';

/// Free Fire–style profile: left tabs · centre character · right ID card.
/// ID card uses [profile_stats_bg] at natural aspect (not tight / clipped).
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // 0 gallery · 1 overview · 2 history

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didUpdateWidget(covariant ProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.name != widget.name) _name = widget.name;
    if (oldWidget.character != widget.character) _character = widget.character;
  }

  String get _uid {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }

  int get _likes {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 17 + b) & 0x7FFFFFFF);
    return 100 + (h % 9900);
  }

  int get _level {
    final h = _character.codeUnits.fold(0, (a, b) => (a * 13 + b) & 0x7FFFFFFF);
    return 1 + (h % 80);
  }

  String get _cat =>
      roster.Characters.byName(_character).category.name.toUpperCase();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0E14),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1A2230),
                  Color(0xFF0B0E14),
                  Color(0xFF050608),
                ],
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 120,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.55),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Row(
                  children: [
                    // LEFT tabs
                    SizedBox(
                      width: w * 0.12,
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _sideTab('GALLERY', 0),
                          _sideTab('OVERVIEW', 1),
                          _sideTab('HISTORY', 2),
                          const Spacer(),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: GestureDetector(
                              onTap: () {
                                Sfx.instance.uiClick();
                                Navigator.pop(context);
                              },
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFE0302C),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.close,
                                    color: Colors.white, size: 20),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // CENTRE character
                    Expanded(
                      flex: 5,
                      child: Center(
                        child: SizedBox(
                          height: h * 0.88,
                          child: CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 0.95,
                            fallbackSeed:
                                _character.codeUnits.fold(0, (a, b) => a + b),
                          ),
                        ),
                      ),
                    ),

                    // RIGHT panel — roomy ID card
                    SizedBox(
                      width: w * 0.40,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(8, 16, 20, 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'PROFILE',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                color: Colors.white54,
                                letterSpacing: 2.5,
                              ),
                            ),
                            const SizedBox(height: 14),

                            // ID card — natural aspect, not squeezed
                            _IdCard(
                              name: _name,
                              level: _level,
                              category: _cat,
                              likes: _likes,
                              uid: _uid,
                              character: _character,
                              onEdit: () {
                                Sfx.instance.uiClick();
                                widget.onEditName();
                              },
                            ),

                            const SizedBox(height: 14),

                            // Ranked row
                            Expanded(
                              child: _tabBody(),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _sideTab(String label, int i) {
    final on = _tab == i;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
      child: GestureDetector(
        onTap: () {
          Sfx.instance.uiClick();
          setState(() => _tab = i);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: on ? const Color(0x33FFC425) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border(
              left: BorderSide(
                color: on ? const Color(0xFFFFC425) : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.6,
              color: on ? const Color(0xFFFFC425) : Colors.white54,
            ),
          ),
        ),
      ),
    );
  }

  Widget _tabBody() {
    switch (_tab) {
      case 1:
        return _statsGrid();
      case 2:
        return const Center(
          child: Text(
            'No match history yet',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
        );
      default:
        return _rankCards();
    }
  }

  Widget _rankCards() {
    return Column(
      children: [
        Expanded(
          child: _rankTile(
            title: 'RUSH RANKED',
            badge: 'GOLD',
            color: const Color(0xFFFFC425),
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: _rankTile(
            title: 'CLASSIC',
            badge: 'SILVER',
            color: const Color(0xFFB0B8C4),
          ),
        ),
      ],
    );
  }

  Widget _rankTile({
    required String title,
    required String badge,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF141A22),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.45)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withValues(alpha: 0.2),
              border: Border.all(color: color, width: 1.5),
            ),
            child: Icon(Icons.emoji_events_rounded, color: color, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: Colors.white54,
                    letterSpacing: 0.8,
                  ),
                ),
                Text(
                  badge,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statsGrid() {
    final items = [
      ('Matches', '128'),
      ('Wins', '54'),
      ('Kills', '210'),
      ('MVP', '12'),
    ];
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      childAspectRatio: 1.6,
      physics: const NeverScrollableScrollPhysics(),
      children: items
          .map(
            (e) => Container(
              decoration: BoxDecoration(
                color: const Color(0xFF141A22),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white12),
              ),
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    e.$1,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Colors.white54,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    e.$2,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}

/// Free Fire ID card — uses asset at natural aspect, generous internal padding.
class _IdCard extends StatelessWidget {
  const _IdCard({
    required this.name,
    required this.level,
    required this.category,
    required this.likes,
    required this.uid,
    required this.character,
    required this.onEdit,
  });

  final String name;
  final int level;
  final String category;
  final int likes;
  final String uid;
  final String character;
  final VoidCallback onEdit;

  // Asset is 834×456 ≈ 1.83
  static const double _aspect = 834 / 456;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: _aspect,
      child: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          // Comfortable insets — never tight to edges
          final padL = w * 0.04;
          final padR = w * 0.04;
          final padT = h * 0.10;
          final padB = h * 0.10;
          final avatar = h * 0.58;

          return Stack(
            fit: StackFit.expand,
            children: [
              // Background plate
              Image.asset(
                'assets/ui/profile_stats_bg.png',
                fit: BoxFit.fill,
                errorBuilder: (_, __, ___) => Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF2A3140), Color(0xFF1A1F28)],
                    ),
                    border: Border.all(
                      color: const Color(0xFFE8A317),
                      width: 2,
                    ),
                  ),
                ),
              ),

              // Content with breathing room
              Padding(
                padding: EdgeInsets.fromLTRB(padL, padT, padR, padB),
                child: Row(
                  children: [
                    // Avatar window
                    Container(
                      width: avatar,
                      height: avatar,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: const Color(0xFFFFC425),
                          width: 1.5,
                        ),
                        color: const Color(0xFF0E1218),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: CharacterPortrait(
                        character: character,
                        size: avatar,
                        radius: 4,
                        borderWidth: 0,
                        alignment: const Alignment(0, -0.25),
                        fallbackSeed:
                            character.codeUnits.fold(0, (a, b) => a + b),
                      ),
                    ),
                    SizedBox(width: w * 0.035),

                    // Text plate
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  name.toUpperCase(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: h * 0.14,
                                    fontWeight: FontWeight.w900,
                                    color: const Color(0xFF1A1F28),
                                    height: 1.05,
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: onEdit,
                                child: Image.asset(
                                  'assets/ui/icon_setting.png',
                                  width: h * 0.16,
                                  height: h * 0.16,
                                  errorBuilder: (_, __, ___) => Icon(
                                    Icons.settings,
                                    size: h * 0.16,
                                    color: const Color(0xFF5A6570),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: h * 0.02),
                          Text(
                            'Lv.$level  ·  $category',
                            style: TextStyle(
                              fontSize: h * 0.11,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF2F6BFF),
                            ),
                          ),
                          const Spacer(),
                          Row(
                            children: [
                              Icon(
                                Icons.thumb_up_alt,
                                size: h * 0.12,
                                color: const Color(0xFF5A6570),
                              ),
                              SizedBox(width: w * 0.012),
                              Text(
                                '$likes',
                                style: TextStyle(
                                  fontSize: h * 0.12,
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF1A1F28),
                                ),
                              ),
                              const Spacer(),
                              Text(
                                'UID:$uid',
                                style: TextStyle(
                                  fontSize: h * 0.09,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF6A7380),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
