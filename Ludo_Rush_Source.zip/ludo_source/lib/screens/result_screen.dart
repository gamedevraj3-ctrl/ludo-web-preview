import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../game/models.dart';
import '../widgets/avatar.dart';
import 'game_screen.dart';

/// ---------------------------------------------------------------------------
/// Update #3 — the victory/result screen was rebuilt a second time, now
/// matching the user's new BOOYAH reference image pixel-for-pixel:
///   • LANDSCAPE layout (the reference itself is landscape — this replaces
///     the earlier portrait-podium design entirely)
///   • dark navy/indigo radial backdrop + scattered confetti flecks
///   • gold "BOOYAH" wordmark top-centre, with a small drop shadow
///   • "YOU ARE MVP" gold pill, "Highest score — N points!" subtitle, and a
///     compact gold "MVP" tag stacked beneath the title
///   • 4 character portraits in a single horizontal row, each with a small
///     dark rank pill ("2nd"/"3rd"/"4th") above the non-winner busts, the
///     winner glowing green/gold and sitting lowest/largest, with the
///     name + score printed under every bust
///   • "LOBBY" outlined button + "PLAY AGAIN" filled purple button side by
///     side at the bottom-centre
/// ---------------------------------------------------------------------------
class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.rows, required this.config});

  final List<ScoreRow> rows;
  final GameConfig config;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _confetti = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  );
  late final AnimationController _entrance = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  late final AnimationController _glow = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat(reverse: true);

  @override
  void initState() {
    super.initState();
    // Landscape, matching the BOOYAH reference screenshot (and the match
    // itself now also plays in landscape) — the old portrait podium layout
    // is gone entirely.
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _persist();
    _entrance.forward();
    // Win/lose fanfare is already fired by the engine itself right before it
    // navigates here (see LudoEngine._finish) — no need to play it again.
    if (widget.rows.first.isMe) _confetti.repeat();
  }

  @override
  void dispose() {
    _confetti.dispose();
    _entrance.dispose();
    _glow.dispose();
    super.dispose();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    final me = widget.rows.firstWhere(
      (r) => r.isMe,
      orElse: () => widget.rows.first,
    );
    final winner = widget.rows.first;
    final best = p.getInt('best') ?? 0;
    if (widget.config.matchMode.isRush && me.score > best) {
      await p.setInt('best', me.score);
    }
    await p.setInt('played', (p.getInt('played') ?? 0) + 1);
    if (winner.isMe) {
      await p.setInt('won', (p.getInt('won') ?? 0) + 1);
      if (widget.config.matchMode.isClassic) {
        await p.setInt('classic_wins', (p.getInt('classic_wins') ?? 0) + 1);
      }
    }
  }

  void _tap() => Sfx.instance.uiClick();

  @override
  Widget build(BuildContext context) {
    final winner = widget.rows.first;
    final iWon = winner.isMe;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.25),
            radius: 1.15,
            colors: [
              Color(0xFF241852),
              Color(0xFF1A1340),
              Color(0xFF0E0B25),
            ],
            stops: [0.0, 0.55, 1.0],
          ),
        ),
        child: Stack(
          children: [
            const Positioned.fill(
              child: IgnorePointer(child: CustomPaint(painter: _VignettePainter())),
            ),
            if (iWon)
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _confetti,
                    builder: (_, __) =>
                        CustomPaint(painter: _ConfettiPainter(_confetti.value)),
                  ),
                ),
              ),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, cts) {
                  final w = cts.maxWidth;
                  final h = cts.maxHeight;
                  // Scale unit off a 960x540 reference landscape canvas.
                  final s = min(w / 960.0, h / 540.0).clamp(0.55, 1.6);

                  return FadeTransition(
                    opacity: CurvedAnimation(
                      parent: _entrance,
                      curve: Curves.easeOut,
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: 8 * s),
                        _title(s),
                        SizedBox(height: 6 * s),
                        _pill(iWon ? 'YOU ARE MVP' : 'MATCH OVER', s),
                        SizedBox(height: 5 * s),
                        _subtitle(winner, iWon, s),
                        SizedBox(height: 5 * s),
                        _pill('MVP', s, compact: true),
                        Expanded(
                          child: _Lineup(rows: widget.rows, scale: s, glow: _glow),
                        ),
                        _actions(s),
                        SizedBox(height: 10 * s),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _title(double s) {
    // Use the real BOOYAH wordmark artwork (assets/ui/booyah_logo.png) so the
    // title matches the Free-Fire reference pixel-for-pixel instead of an
    // approximated text style.
    return Image.asset(
      'assets/ui/booyah_logo.png',
      height: 56 * s,
      filterQuality: FilterQuality.high,
    );
  }

  Widget _pill(String text, double s, {bool compact = false}) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: (compact ? 14 : 20) * s,
        vertical: (compact ? 3.5 : 5) * s,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFFFC425),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFFC425).withValues(alpha: 0.45),
            blurRadius: 10 * s,
          ),
        ],
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: (compact ? 9.5 : 11) * s,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.0,
          color: const Color(0xFF100E29),
        ),
      ),
    );
  }

  Widget _subtitle(ScoreRow winner, bool iWon, double s) {
    final m = widget.config.matchMode;
    final String text;
    if (m.isClassic) {
      text = iWon
          ? 'You brought all ${winner.tokensHome} tokens home first!'
          : '${winner.name} got their tokens home first';
    } else if (m.isKill) {
      text = iWon
          ? 'Unlocked + all ${winner.tokensHome} tokens home — BOOYAH!'
          : '${winner.name} unlocked and finished all tokens home';
    } else if (m.isDeathMatch) {
      text = iWon
          ? 'You hit ${winner.score} kills — BOOYAH!'
          : '${winner.name} won with ${winner.score} kills';
    } else {
      // Rush
      text = iWon
          ? 'Highest score — ${winner.score} points!'
          : '${winner.name} scored highest with ${winner.score} pts';
    }
    return Text(
      text,
      textAlign: TextAlign.center,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: 12.5 * s,
        fontWeight: FontWeight.w600,
        color: const Color(0xFFC2C4E2),
      ),
    );
  }

  Widget _actions(double s) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 120 * s),
      child: Row(
        children: [
          Expanded(
            child: SizedBox(
              height: 40 * s,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF5A54D6), width: 1.5),
                  backgroundColor: const Color(0xFF15113B).withValues(alpha: 0.7),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14 * s),
                  ),
                ),
                onPressed: () {
                  _tap();
                  Navigator.of(context).pop();
                },
                child: Text(
                  'LOBBY',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 12.5 * s,
                    letterSpacing: 0.6,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(width: 14 * s),
          Expanded(
            child: SizedBox(
              height: 40 * s,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF5747D6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14 * s),
                  ),
                ),
                onPressed: () {
                  _tap();
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (_) => GameScreen(config: widget.config),
                    ),
                  );
                },
                child: Text(
                  'PLAY AGAIN',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 12.5 * s,
                    letterSpacing: 0.6,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 3D podium lineup: 3rd — 1st(MVP) — 2nd — 4th with perspective stages.
class _Lineup extends StatelessWidget {
  const _Lineup({required this.rows, required this.scale, required this.glow});

  final List<ScoreRow> rows;
  final double scale;
  final Animation<double> glow;

  @override
  Widget build(BuildContext context) {
    // Map podium rank -> display order & relative vertical offset, matching
    // the reference: 3rd far-left (slightly raised), MVP centre-left
    // (lowest/largest), 2nd centre-right (slightly raised), 4th far-right
    // (raised a touch more than 3rd).
    final byRank = <int, ScoreRow>{};
    for (var i = 0; i < rows.length && i < 4; i++) {
      byRank[i + 1] = rows[i];
    }
    // (rank, dy fraction of bust height, isWinner)
    const order = <(int, double)>[
      (3, -0.18),
      (1, 0.0),
      (2, -0.12),
      (4, -0.22),
    ];

    final busts = <Widget>[];
    for (final (rank, dy) in order) {
      final row = byRank[rank];
      if (row == null) continue;
      busts.add(
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4 * scale),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Transform.translate(
                offset: Offset(0, dy * 160 * scale),
                child: _Bust(
                  row: row,
                  rank: rank,
                  scale: scale,
                  glow: glow,
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 30 * scale),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: busts,
      ),
    );
  }
}

class _Bust extends StatelessWidget {
  const _Bust({
    required this.row,
    required this.rank,
    required this.scale,
    required this.glow,
  });

  final ScoreRow row;
  final int rank;
  final double scale;
  final Animation<double> glow;

  bool get isWinner => rank == 1;

  String get _ordinal => switch (rank) {
    1 => '1st',
    2 => '2nd',
    3 => '3rd',
    _ => '4th',
  };

  // Podium block height by rank (1st tallest)
  double get _podiumH => switch (rank) {
        1 => 52.0 * scale,
        2 => 36.0 * scale,
        3 => 28.0 * scale,
        _ => 20.0 * scale,
      };

  Color get _podiumTop => switch (rank) {
        1 => const Color(0xFFFFD54F),
        2 => const Color(0xFFC0C7D6),
        3 => const Color(0xFFCD7F32),
        _ => const Color(0xFF5A5478),
      };

  Color get _podiumSide => switch (rank) {
        1 => const Color(0xFFB8860B),
        2 => const Color(0xFF7A8499),
        3 => const Color(0xFF8B5A2B),
        _ => const Color(0xFF3A3558),
      };

  @override
  Widget build(BuildContext context) {
    final busyW = (isWinner ? 110.0 : 86.0) * scale;
    final busyH = busyW * 1.28;
    final podH = _podiumH;
    final podW = busyW * (isWinner ? 1.05 : 0.95);

    return Transform(
      alignment: Alignment.bottomCenter,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.0012)
        ..rotateX(-0.18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!isWinner)
            Padding(
              padding: EdgeInsets.only(bottom: 4 * scale),
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 9 * scale,
                  vertical: 2.5 * scale,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF1C1640),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white24, width: 1),
                ),
                child: Text(
                  _ordinal,
                  style: TextStyle(
                    fontSize: 10 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          // character bust with depth shadow
          SizedBox(
            width: busyW,
            height: busyH,
            child: Stack(
              alignment: Alignment.bottomCenter,
              clipBehavior: Clip.none,
              children: [
                if (isWinner)
                  AnimatedBuilder(
                    animation: glow,
                    builder: (_, __) => Container(
                      width: busyW * 1.45,
                      height: busyW * 1.45,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            const Color(0xFF59E06B).withValues(
                              alpha: 0.36 + 0.14 * glow.value,
                            ),
                            const Color(0xFF59E06B).withValues(alpha: 0.0),
                          ],
                        ),
                      ),
                    ),
                  ),
                // soft ground shadow under feet
                Positioned(
                  bottom: 2 * scale,
                  child: Container(
                    width: busyW * 0.7,
                    height: 10 * scale,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.45),
                          blurRadius: 12 * scale,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                ),
                CharacterBlend(
                  character: row.character,
                  alignment: Alignment.bottomCenter,
                  widthFactor: 1.0,
                  fallbackSeed: row.name.codeUnits.fold(0, (a, b) => a + b),
                ),
              ],
            ),
          ),
          // 3D podium block
          SizedBox(
            width: podW,
            height: podH,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                // side face (depth)
                Positioned(
                  left: 4 * scale,
                  right: -4 * scale,
                  top: 6 * scale,
                  bottom: -4 * scale,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4 * scale),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          _podiumSide.withValues(alpha: 0.95),
                          _podiumSide.withValues(alpha: 0.55),
                        ],
                      ),
                    ),
                  ),
                ),
                // top face
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5 * scale),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          _podiumTop,
                          _podiumSide,
                        ],
                      ),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.25),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.4),
                          blurRadius: 8 * scale,
                          offset: Offset(0, 4 * scale),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      isWinner ? '1st' : _ordinal,
                      style: TextStyle(
                        fontSize: (isWinner ? 14 : 11) * scale,
                        fontWeight: FontWeight.w900,
                        color: Colors.white.withValues(alpha: 0.95),
                        shadows: const [
                          Shadow(color: Colors.black54, blurRadius: 4),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 5 * scale),
          Text(
            row.isMe ? 'You' : row.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: (isWinner ? 13 : 11) * scale,
              fontWeight: FontWeight.w900,
              color: isWinner ? const Color(0xFF7CFF79) : Colors.white,
            ),
          ),
          Text(
            '${row.score} pts',
            style: TextStyle(
              fontSize: (isWinner ? 11 : 9.5) * scale,
              fontWeight: FontWeight.w800,
              color:
                  isWinner ? const Color(0xFFFFD23F) : const Color(0xFFC2C4E2),
            ),
          ),
        ],
      ),
    );
  }
}

/// Subtle vignette so the busts/title stay the visual focus against the
/// dark navy/indigo radial backdrop.
class _VignettePainter extends CustomPainter {
  const _VignettePainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 1.0,
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.38)],
          stops: const [0.55, 1.0],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant _VignettePainter oldDelegate) => false;
}

/// Lightweight procedural confetti — no packages, no assets.
class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.t);

  /// 0..1 loop progress.
  final double t;

  static const int _count = 70;
  static final Random _rnd = Random(7);
  static final List<_Fleck> _flecks = List.generate(
    _count,
    (i) => _Fleck(
      x: _rnd.nextDouble(),
      phase: _rnd.nextDouble(),
      speed: 0.55 + _rnd.nextDouble() * 0.85,
      sway: 0.012 + _rnd.nextDouble() * 0.045,
      swaySpeed: 1.5 + _rnd.nextDouble() * 3.5,
      size: 4.0 + _rnd.nextDouble() * 6.0,
      spin: _rnd.nextDouble() * 6.0 - 3.0,
      color: _palette[i % _palette.length],
      round: _rnd.nextBool(),
    ),
  );

  static const List<Color> _palette = [
    Color(0xFF00E5FF), // cyan
    Color(0xFFF8E71C), // yellow
    Color(0xFFFF2D55), // pink
    Color(0xFF50E3C2), // mint
    Color(0xFFB78CFF), // purple
    Colors.white,
  ];

  @override
  void paint(Canvas canvas, Size size) {
    for (final f in _flecks) {
      // vertical fall, wrapping around
      final prog = (t * f.speed + f.phase) % 1.0;
      final y = prog * (size.height + 60) - 30;
      final x =
          f.x * size.width +
          sin((prog * f.swaySpeed + f.phase) * 2 * pi) * size.width * f.sway;

      // fade out near the bottom
      final fade = prog > 0.85 ? (1 - prog) / 0.15 : 1.0;
      final paint = Paint()..color = f.color.withValues(alpha: 0.85 * fade);

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate((prog * f.spin) * 2 * pi);
      if (f.round) {
        canvas.drawCircle(Offset.zero, f.size * 0.42, paint);
      } else {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
              center: Offset.zero,
              width: f.size,
              height: f.size * 0.55,
            ),
            Radius.circular(f.size * 0.16),
          ),
          paint,
        );
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter old) => old.t != t;
}

class _Fleck {
  const _Fleck({
    required this.x,
    required this.phase,
    required this.speed,
    required this.sway,
    required this.swaySpeed,
    required this.size,
    required this.spin,
    required this.color,
    required this.round,
  });

  final double x;
  final double phase;
  final double speed;
  final double sway;
  final double swaySpeed;
  final double size;
  final double spin;
  final Color color;
  final bool round;
}
